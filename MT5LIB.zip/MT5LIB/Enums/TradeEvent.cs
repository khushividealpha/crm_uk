﻿namespace MT5LIB.Enums;

public enum TradeEvent
{
    None,
    Open,
    Close,
    Place,
    Modify,
    Delete,
    Perform,
}