﻿namespace CLIB.Constants;

public class AppRoles
{
    public const string Admin = "admin";
    public const string Client = "client";
}
