﻿namespace CLIB
{
    public class Class1
    {

    }
}
